<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">

        <meta name="application-name" content="<?php echo e(config('app.name')); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name')); ?></title>

        <!-- Styles -->
        <style>[x-cloak] { display: none !important; }</style>
        <?php echo \Livewire\Livewire::styles(); ?>

        

        <!-- Scripts -->
        <?php echo \Livewire\Livewire::scripts(); ?>

        
        <?php echo $__env->yieldPushContent('scripts'); ?>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>

    <body class="antialiased">
        <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo e($slot); ?>

    </body>
</html>
<?php /**PATH C:\belajar\wedding-invitation-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>