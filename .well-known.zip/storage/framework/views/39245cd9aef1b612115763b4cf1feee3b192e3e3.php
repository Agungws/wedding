<div <?php echo e($attributes); ?>><?php echo $toHtml($slot); ?></div>
<?php /**PATH /home/rach2467/public_html/vendor/spatie/laravel-markdown/src/../resources/views/markdown.blade.php ENDPATH**/ ?>