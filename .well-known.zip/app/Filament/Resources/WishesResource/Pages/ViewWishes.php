<?php

namespace App\Filament\Resources\WishesResource\Pages;

use App\Filament\Resources\WishesResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewWishes extends ViewRecord
{
    protected static string $resource = WishesResource::class;
}
