<?php

namespace App\Filament\Resources\BrideResource\Pages;

use App\Filament\Resources\BrideResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewBride extends ViewRecord
{
    protected static string $resource = BrideResource::class;
}
